const text = document.getElementById("text");
const button = document.getElementById("new-quote");

let currentQ = ["Insane means fewer cameras!", "Never ask an elf for help; they might decide your better off dead, eh?", "What is my age again?", "Be yourself; everyone else is already taken.","Two things are infinite: the universe and human stupidity; and I'm not sure about the universe.","So many books, so little time.","A room without books is like a body without a soul.","Be who you are and say what you feel, because those who mind don't matter, and those who matter don't mind.","You know you're in love when you can't fall asleep because reality is finally better than your dreams.","You only live once, but if you do it right, once is enough.","Be the change that you wish to see in the world.","In three words I can sum up everything I've learned about life: it goes on.","If you want to know what a man's like, take a good look at how he treats his inferiors, not his equals."
];

let currentColor = ['#16a085',
  '#FB6964',
  '#27ae60',
  '#2c3e50',
  '#e74c3c',
  '#9b59b6',
  '#472E32',
  '#f39c12',
  '#342224',
  '#77B1A9',
  '#BDBB99',
  '#73A857']

button.addEventListener('click', function(){

let randomQ = currentQ[Math.floor(Math.random() * currentQ.length)];

text.innerHTML = "''" + randomQ + "''";

})
button.addEventListener('click', function(){
  let randomColor = currentColor[Math.floor(Math.random() * currentColor.length)];
  document.body.style.backgroundColor = randomColor;
  document.getElementById("text").style.color = randomColor;
  document.getElementById("new-quote").style.backgroundColor = randomColor;
})